import "./index.css";
import { Composition } from 'remotion';
import { PaperNotes } from './Video';
import { RealMaterialDemo } from './RealMaterialDemo';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition id="PaperNotes" component={PaperNotes} durationInFrames={900} fps={30} width={1440} height={1080}/>
      <Composition id="RealMaterialDemo" component={RealMaterialDemo} durationInFrames={540} fps={30} width={1440} height={1080}/>
    </>
  );
};
