// Reconstruction defaults, not claimed to be exact source values.
export const tokens = {
  canvas: {width: 1440, height: 1080, fps: 30},
  color: {
    paper: '#F7F7ED', ink: '#181A17', muted: '#5B5D57', white: '#FFFFFF',
    lime: '#CDFF36', cyan: '#93E2F2', purple: '#B298ED',
    pink: '#F3AFD1', yellow: '#FFEA68', coral: '#F77174', mint: '#98E9BD',
  },
  type: {font: '"Paper Sans", "PingFang SC", sans-serif', title: 76, body: 32, cardTitle: 45, caption: 31},
  layout: {margin: 88, contentWidth: 1264, bodyTop: 390, captionTop: 932},
  line: {border: 4, radius: 24, shadow: 10},
  motion: {enterFrames: 12, staggerFrames: 9, exitFrames: 8},
} as const;
export type Accent = 'lime' | 'cyan' | 'purple' | 'pink' | 'yellow' | 'coral' | 'mint';
