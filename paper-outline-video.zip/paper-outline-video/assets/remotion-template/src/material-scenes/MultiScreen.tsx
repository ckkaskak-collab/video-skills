import React from 'react';
import {Reveal,SceneFrame} from '../components';
import {MaterialWindow} from '../MaterialWindow';
import {materials} from '../materials';
import {materialFooter, materialSceneData} from './data';
export const MultiScreen:React.FC = ()=><SceneFrame data={materialSceneData[2]} number={3} total={3} footer={materialFooter}>
  <Reveal at={27} style={{position:'absolute',left:88,top:403}}><MaterialWindow asset={materials.molecule} width={579} height={475} label="3D 可视化 · 截图" accent="lime"/></Reveal>
  <Reveal at={37} style={{position:'absolute',left:701,top:403}}><MaterialWindow asset={materials.experiment} width={639} height={224} label="模拟实验 · 截图" accent="yellow"/></Reveal>
  <Reveal at={47} style={{position:'absolute',left:701,top:652}}><MaterialWindow asset={materials.coding} width={639} height={226} label="在线编程 · 截图" accent="cyan"/></Reveal>
</SceneFrame>;
