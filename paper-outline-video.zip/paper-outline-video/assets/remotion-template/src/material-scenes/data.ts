import type {SceneData} from '../content';
export const materialSceneData:SceneData[] = [
  {label:'品牌识别',before:'先认出，',emphasis:'正在讲的产品',description:'真实标识与讲解标签组合，让观众建立明确的产品印象。',accent:'purple',tags:['REAL LOGO','PRODUCT IDENTITY'],items:[],summary:'',captions:[{from:0,to:180,text:'保留真实的产品标识，再用标签组织信息。'}]},
  {label:'真实界面',before:'讲到功能，',emphasis:'就把界面展示出来',description:'给真实素材足够大的位置，用旁边的短句说明当前看点。',accent:'pink',tags:['PRODUCT SCREEN','STATIC REFERENCE'],items:[],summary:'',captions:[{from:0,to:180,text:'这里使用用户提供的课堂截图，展示真实界面。'}]},
  {label:'多窗口演示',before:'不同能力，',emphasis:'配不同的真实画面',description:'一大两小用于概览；讲到某个细节时，再切换到对应的大窗口。',accent:'yellow',tags:['3D','EXPERIMENT','CODE'],items:[],summary:'',captions:[{from:0,to:180,text:'三维模型、模拟实验和代码界面，各有对应的素材。'}]},
];
export const materialFooter='素材：用户提供截图 · 静态参考';
