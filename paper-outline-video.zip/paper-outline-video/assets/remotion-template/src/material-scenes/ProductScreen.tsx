import React from 'react';
import {Card,Reveal,SceneFrame} from '../components';
import {MaterialWindow} from '../MaterialWindow';
import {materials} from '../materials';
import {tokens as t} from '../tokens';
import {materialFooter, materialSceneData} from './data';
export const ProductScreen:React.FC = ()=><SceneFrame data={materialSceneData[1]} number={2} total={3} footer={materialFooter}>
  <Reveal at={28} style={{position:'absolute',left:88,top:408}}><Card accent="cyan" style={{width:348,height:187,padding:25}}><div style={{fontSize:21,color:t.color.muted}}>这一屏看什么</div><div style={{fontSize:36,fontWeight:800,marginTop:22}}>课堂内容与界面</div></Card></Reveal>
  <Reveal at={43} style={{position:'absolute',left:95,top:647,width:326,fontSize:29,lineHeight:1.8,color:t.color.muted}}>素材负责展示。<br/>短句帮助观众<br/>找到当前的重点。</Reveal>
  <Reveal at={33} style={{position:'absolute',left:475,top:402}}><MaterialWindow asset={materials.classroom} width={864} height={487} label="OpenMAIC · 课堂界面截图" accent="pink"/></Reveal>
</SceneFrame>;
