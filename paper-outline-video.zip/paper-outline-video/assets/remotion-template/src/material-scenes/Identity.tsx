import React from 'react';
import {Card,Reveal,SceneFrame} from '../components';
import {MaterialViewport} from '../MaterialWindow';
import {materials} from '../materials';
import {tokens as t, type Accent} from '../tokens';
import {materialFooter, materialSceneData} from './data';
export const Identity:React.FC = ()=><SceneFrame data={materialSceneData[0]} number={1} total={3} footer={materialFooter}>
  <Reveal at={28} style={{position:'absolute',left:88,top:411}}><Card accent="purple" style={{width:786,height:408,padding:30,background:'#FFFEF9'}}><MaterialViewport asset={materials.logo} width={718} height={198}/><div style={{height:2,background:'#DDDDD4',margin:'18px 0 21px'}}/><div style={{fontSize:32,fontWeight:650,textAlign:'center'}}>产品名称与标识保持原样</div></Card></Reveal>
  <div style={{position:'absolute',left:927,top:411,width:407,display:'grid',gap:23}}>{(['识别产品','对应解说','记录来源'] as const).map((label,i)=><Reveal at={37+i*9} key={label}><Card accent={(['lime','cyan','pink'] as Accent[])[i]} style={{height:119,padding:25,display:'flex',alignItems:'center',gap:21}}><span style={{fontSize:20,color:t.color.muted}}>0{i+1}</span><b style={{fontSize:37}}>{label}</b></Card></Reveal>)}</div>
</SceneFrame>;
