import React from 'react';
import {TransitionSeries} from '@remotion/transitions';
import {FontGate} from './components';
import {content} from './content';
import {Hero} from './scenes/Hero';
import {Columns} from './scenes/Columns';
import {Workflow} from './scenes/Workflow';
import {Evidence} from './scenes/Evidence';
import {Rows} from './scenes/Rows';

export const PaperNotes:React.FC = () => <><FontGate/><TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={180} name="开场观点"><Hero data={content[0]}/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="三栏分类"><Columns data={content[1]}/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="四步流程"><Workflow data={content[2]}/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="示意演示"><Evidence data={content[3]}/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="行动收束"><Rows data={content[4]}/></TransitionSeries.Sequence>
</TransitionSeries></>;
