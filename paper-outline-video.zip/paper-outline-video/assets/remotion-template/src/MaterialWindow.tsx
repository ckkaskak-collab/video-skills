import React from 'react';
import {Img, staticFile} from 'remotion';
import {Video} from '@remotion/media';
import {Card} from './components';
import {tokens as t, type Accent} from './tokens';
import type {Material} from './materials';

export const MaterialViewport:React.FC<{asset:Material;width:number;height:number}> = ({asset,width,height}) => {
  const crop = asset.crop ?? {x:0,y:0,width:asset.width,height:asset.height};
  const scale = Math.min(width / crop.width, height / crop.height);
  const viewportWidth = crop.width * scale;
  const viewportHeight = crop.height * scale;
  const mediaStyle:React.CSSProperties = {position:'absolute',width:asset.width*scale,height:asset.height*scale,left:-crop.x*scale,top:-crop.y*scale,maxWidth:'none'};
  return <div style={{width,height,display:'flex',alignItems:'center',justifyContent:'center',background:'#FFFEF9'}}>
    <div style={{position:'relative',width:viewportWidth,height:viewportHeight,overflow:'hidden'}}>
      {asset.kind==='video' ? <Video src={staticFile(asset.src)} muted objectFit="contain" style={mediaStyle}/> : <Img src={staticFile(asset.src)} style={mediaStyle}/>}
    </div>
  </div>;
};

export const MaterialWindow:React.FC<{asset:Material;width:number;height:number;label:string;accent:Accent}> = ({asset,width,height,label,accent}) => <Card accent={accent} style={{width,height,padding:0,overflow:'hidden',borderRadius:25}}>
  <div style={{height:46,padding:'8px 17px',fontSize:21,fontWeight:650,background:t.color.paper,borderBottom:`2px solid ${t.color.ink}`}}>{label}</div>
  <MaterialViewport asset={asset} width={width-8} height={height-54}/>
</Card>;
