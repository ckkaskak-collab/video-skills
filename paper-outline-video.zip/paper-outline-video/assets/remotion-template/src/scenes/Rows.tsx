import React from 'react';
import {Card, Reveal, SceneFrame} from '../components';
import type {SceneData} from '../content';
import {tokens as t} from '../tokens';
export const Rows: React.FC<{data:SceneData}> = ({data}) => <SceneFrame data={data} number={5}>
  <div style={{position:'absolute',left:110,right:110,top:413,display:'grid',gap:28}}>{data.items.map((item,i)=><Reveal key={item.title} at={28+i*10}><Card accent={item.accent} style={{height:112,padding:'22px 28px',display:'flex',alignItems:'center',gap:28}}><span style={{fontSize:19,fontFamily:'monospace',color:t.color.muted}}>0{i+1}</span><strong style={{fontSize:35,width:350}}>{item.title}</strong><span style={{fontSize:27,color:t.color.muted}}>{item.description}</span></Card></Reveal>)}</div>
</SceneFrame>;
