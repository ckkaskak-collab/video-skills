import React from 'react';
import {Card, MediaPanel, Reveal, SceneFrame} from '../components';
import type {SceneData} from '../content';
import {tokens as t} from '../tokens';
export const Evidence: React.FC<{data:SceneData}> = ({data}) => <SceneFrame data={data} number={4}>
  <div style={{position:'absolute',left:88,top:415,width:368,display:'grid',gap:28}}>{data.items.map((item,i)=><Reveal key={item.title} at={28+i*10}><Card accent={item.accent} style={{padding:27,height:185}}><div style={{fontSize:36,fontWeight:850}}>{item.title}</div><div style={{fontSize:26,color:t.color.muted,whiteSpace:'pre-line',marginTop:16,lineHeight:1.5}}>{item.description}</div></Card></Reveal>)}</div>
  <Reveal at={35} style={{position:'absolute',left:502,top:414,width:834,height:406}}><MediaPanel accent="pink" label="project-note.md · 示意笔记">
    <div style={{padding:'23px 33px'}}><div style={{fontSize:36,fontWeight:850,marginBottom:18}}>视频项目 · 今日记录</div><div style={{display:'grid',gridTemplateColumns:'120px 1fr',gap:18,fontSize:28,lineHeight:1.7}}><b>已完成</b><span>整理了 3 条参考视频</span><b>关键决定</b><span>采用 4:3 图解卡片版式</span><b style={{background:t.color.lime}}>下一步</b><span style={{background:'#F0F9D8'}}>完成第一版分镜</span></div><div style={{fontSize:18,color:t.color.muted,marginTop:20}}>用结论和行动，连接下一次工作。</div></div>
  </MediaPanel></Reveal>
</SceneFrame>;
