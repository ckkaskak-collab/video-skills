import React from 'react';
import {Card, Reveal, SceneFrame, Summary} from '../components';
import type {SceneData} from '../content';
import {tokens as t} from '../tokens';

export const Hero: React.FC<{data:SceneData}> = ({data}) => <SceneFrame data={data} number={1}>
  <Reveal at={27} style={{position:'absolute',left:88,top:405,width:526,height:350}}>
    <Card accent="purple" style={{height:'100%',padding:38}}>
      <div style={{fontSize:20,fontFamily:'monospace',color:t.color.muted}}>PROJECT NOTE / 001</div>
      <div style={{fontSize:57,fontWeight:850,marginTop:24}}>今天的工作</div>
      <div style={{height:8,width:88,background:t.color.lime,margin:'20px 0'}}/>
      <div style={{fontSize:31,lineHeight:1.75,color:t.color.muted}}>记录背景与进度<br/>留下明确的下一步</div>
    </Card>
  </Reveal>
  <Reveal at={45} style={{position:'absolute',left:642,top:540,fontSize:64}}>→</Reveal>
  <div style={{position:'absolute',left:742,top:405,width:597,display:'grid',gap:19}}>{data.items.map((item,i) => <Reveal key={item.title} at={66+i*16}><Card accent={item.accent} style={{padding:'15px 23px',height:102,display:'flex',alignItems:'center',gap:26}}><span style={{fontSize:17,fontFamily:'monospace',color:t.color.muted}}>0{i+1}</span><span style={{fontSize:34,fontWeight:800}}>{item.title}</span></Card></Reveal>)}</div>
  <Summary text={data.summary} accent={data.accent} at={66+data.items.length*16+6}/>
</SceneFrame>;
