import React from 'react';
import {Card, Reveal, SceneFrame, Summary} from '../components';
import type {SceneData} from '../content';
import {tokens as t} from '../tokens';
export const Workflow: React.FC<{data:SceneData}> = ({data}) => <SceneFrame data={data} number={3}>
  <div style={{position:'absolute',left:88,right:100,top:425,display:'grid',gridTemplateColumns:'repeat(4, 1fr)',gap:28}}>{data.items.map((item,i)=><Reveal key={item.title} at={28+i*9}><Card accent={item.accent} style={{height:302,padding:28}}><div style={{fontFamily:'monospace',fontSize:20,color:t.color.muted}}>0{i+1}</div><div style={{height:9,width: sixty,background:t.color[item.accent],margin:'28px 0 20px'}}/><div style={{fontSize:56,fontWeight:850}}>{item.title}</div><div style={{fontSize:29,color:t.color.muted,marginTop:16}}>{item.description}</div></Card></Reveal>)}</div>
  <Summary text={data.summary} accent="purple"/>
</SceneFrame>;
const sixty = 60;
