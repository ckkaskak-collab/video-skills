import React from 'react';
import {Card, Reveal, SceneFrame, Summary} from '../components';
import type {SceneData} from '../content';
import {tokens as t} from '../tokens';
export const Columns: React.FC<{data:SceneData}> = ({data}) => <SceneFrame data={data} number={2}>
  <div style={{position:'absolute',left:88,right:100,top:413,display:'grid',gridTemplateColumns:'repeat(3, 1fr)',gap:28}}>{data.items.map((item,i)=><Reveal key={item.title} at={29+i*10}><Card accent={item.accent} style={{height:335,padding:32}}><div style={{fontFamily:'monospace',fontSize:20,color:t.color.muted}}>0{i+1}</div><div style={{fontSize:52,fontWeight:850,marginTop:22}}>{item.title}</div><div style={{width: sixty, height:9,background:t.color[item.accent],margin:'20px 0'}}/><div style={{fontSize:31,lineHeight:1.75,whiteSpace:'pre-line',color:t.color.muted}}>{item.description}</div></Card></Reveal>)}</div>
  <Summary text={data.summary} accent="lime"/>
</SceneFrame>;
const sixty = 60;
