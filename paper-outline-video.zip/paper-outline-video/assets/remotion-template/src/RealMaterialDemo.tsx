import React from 'react';
import {TransitionSeries} from '@remotion/transitions';
import {FontGate} from './components';
import {Identity} from './material-scenes/Identity';
import {ProductScreen} from './material-scenes/ProductScreen';
import {MultiScreen} from './material-scenes/MultiScreen';
export const RealMaterialDemo:React.FC = ()=><><FontGate/><TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={180} name="产品标识"><Identity/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="大幅真实界面"><ProductScreen/></TransitionSeries.Sequence>
  <TransitionSeries.Sequence durationInFrames={180} name="一大两小素材窗"><MultiScreen/></TransitionSeries.Sequence>
</TransitionSeries></>;
