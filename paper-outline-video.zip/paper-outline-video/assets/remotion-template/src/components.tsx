import React, {useEffect, useState} from 'react';
import {AbsoluteFill, cancelRender, continueRender, delayRender, Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {tokens as t, type Accent} from './tokens';
import type {SceneData} from './content';

const clamped = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.bezier(.22, 1, .36, 1)} as const;
let fontPromise: Promise<void> | undefined;
export const FontGate: React.FC = () => {
  const [handle] = useState(() => delayRender('Load bundled Chinese font'));
  useEffect(() => {
    fontPromise ??= new FontFace('Paper Sans', `url("${staticFile('fonts/NotoSansSC.ttf')}")`, {weight: '100 900'}).load().then(font => {document.fonts.add(font);});
    fontPromise.then(() => continueRender(handle)).catch(cancelRender);
  }, [handle]);
  return null;
};

export const Reveal: React.FC<React.PropsWithChildren<{at?: number; style?: React.CSSProperties}>> = ({at = 0, style, children}) => {
  const frame = useCurrentFrame();
  return <div style={{...style, opacity: interpolate(frame, [at, at + 12], [0, 1], clamped), translate: `0px ${interpolate(frame, [at, at + 12], [24, 0], clamped)}px`}}>{children}</div>;
};

export const PaperBackground: React.FC<{accent: Accent}> = ({accent}) => <AbsoluteFill style={{background: t.color.paper, overflow: 'hidden'}}>
  <AbsoluteFill style={{opacity: .28, backgroundImage: 'linear-gradient(#e2e4d7 1px, transparent 1px), linear-gradient(90deg, #e2e4d7 1px, transparent 1px)', backgroundSize: '116px 116px'}} />
  <div style={{position:'absolute', width: 540, height: 540, right: -240, bottom: -260, borderRadius: '50%', background: t.color[accent], opacity: .29}} />
  <div style={{position: 'absolute', left: -80, top: 216, width: 165, height: 105, border: `12px solid ${t.color[accent]}`, borderRadius: 24, rotate: '13deg', opacity: .20}} />
</AbsoluteFill>;

export const Card: React.FC<React.PropsWithChildren<{accent: Accent; style?: React.CSSProperties; fill?: boolean}>> = ({accent, style, fill, children}) => <div data-box="card" style={{background: fill ? t.color[accent] : t.color.white, border: `${t.line.border}px solid ${t.color.ink}`, borderRadius: t.line.radius, boxShadow: `${t.line.shadow}px ${t.line.shadow}px 0 ${t.color[accent]}`, padding: 30, ...style}}>{children}</div>;

export const Marker: React.FC<React.PropsWithChildren<{accent: Accent; at?: number}>> = ({accent, at = 14, children}) => {
  const frame = useCurrentFrame();
  return <span style={{position: 'relative', display: 'inline-block', whiteSpace: 'nowrap'}}>
    <span style={{position:'absolute', left:-3, bottom: 3, width:'calc(100% + 6px)', height:'47%', background:t.color[accent], transformOrigin:'left center', scale:`${interpolate(frame, [at, at+12], [0,1], clamped)} 1`}} />
    <span style={{position:'relative'}}>{children}</span>
  </span>;
};

export const Tags: React.FC<{tags: string[]}> = ({tags}) => <div style={{display:'flex', gap:14}}>{tags.map((tag, i) => <Reveal key={tag} at={18+i*5}><div style={{border:`2px solid ${t.color.ink}`, borderRadius:7, background:t.color.paper, padding:'5px 12px', fontSize:16, fontFamily:'monospace', fontWeight:700}}>{tag}</div></Reveal>)}</div>;

export const Summary: React.FC<{text: string; accent: Accent; at?: number}> = ({text, accent, at=62}) => <Reveal at={at} style={{position:'absolute', left:174, right:174, top:802}}><Card accent={accent} style={{padding:'16px 24px', borderRadius:23, display:'flex', alignItems:'center', justifyContent:'center', gap:22}}><span style={{fontSize:16, color:t.color.muted, fontFamily:'monospace'}}>TAKEAWAY</span><span data-text="summary" style={{fontSize:32,fontWeight:750}}>{text}</span></Card></Reveal>;

export const SceneFrame: React.FC<React.PropsWithChildren<{data:SceneData; number:number; total?:number; footer?:string; showFooters?:boolean}>> = ({data, number, total=5, footer='AI NOTES / CONTINUOUS WORK', showFooters=false, children}) => {
  const frame = useCurrentFrame();
  const caption = data.captions.find(c => frame >= c.from && frame < c.to);
  return <AbsoluteFill style={{fontFamily:t.type.font, color:t.color.ink}}>
    <PaperBackground accent={data.accent}/>
    <AbsoluteFill style={{opacity: interpolate(frame,[171,179],[1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
      <Reveal at={0} style={{position:'absolute', left:88, top:65}}><div style={{display:'inline-block',background:t.color[data.accent],border:`3px solid ${t.color.ink}`,borderRadius:28,padding:'5px 19px',fontSize:24,fontWeight:800,boxShadow:`5px 5px 0 ${t.color.purple}`}}>{data.label}</div></Reveal>
      <div style={{position:'absolute', right:88, top:78, fontSize:18,fontFamily:'monospace',color:t.color.muted}}>{String(number).padStart(2,'0')} / {String(total).padStart(2,'0')}</div>
      <Reveal at={5} style={{position:'absolute',left:88,top:150,right:80}}><div data-text="headline" style={{fontSize:t.type.title,lineHeight:1.25,fontWeight:900,letterSpacing:-3,whiteSpace:'nowrap'}}>{data.before}<Marker accent={data.accent}>{data.emphasis}</Marker>{data.after}</div></Reveal>
      <Reveal at={12} style={{position:'absolute',left:90,top:267,right:88}}><div data-text="description" style={{fontSize:29,color:t.color.muted,fontWeight:550}}>{data.description}</div></Reveal>
      <div style={{position:'absolute',left:90,top:327}}><Tags tags={data.tags}/></div>
      {children}
      {showFooters && <>
      <div style={{position:'absolute',left:72,bottom:38,fontSize:16,fontFamily:'monospace',color:t.color.muted}}>{footer}</div>
      <div style={{position:'absolute',right:72,bottom:38,fontSize:16,fontFamily:'monospace',color:t.color.muted}}>PAPER OUTLINE · {String(number).padStart(2,'0')}</div>
      </>}
    </AbsoluteFill>
    {caption && <div style={{position:'absolute',top:t.layout.captionTop,left:72,right:72,display:'flex',justifyContent:'center'}}><div data-text="caption" style={{maxWidth:1230,padding:'10px 24px',border:`3px solid ${t.color.ink}`,borderRadius:13,boxShadow:`6px 6px 0 ${t.color.coral}`,background:t.color.paper,fontSize:t.type.caption,fontWeight:700,lineHeight:1.35,textAlign:'center'}}>{caption.text}</div></div>}
  </AbsoluteFill>;
};

// Optional real screenshot support. The demo supplies vector content instead.
export const MediaPanel: React.FC<React.PropsWithChildren<{src?:string; accent:Accent; label:string}>> = ({src, accent, label, children}) => <Card accent={accent} style={{height:'100%',padding:0,overflow:'hidden'}}>
  <div style={{height:50,borderBottom:'2px solid #181A17',display:'flex',alignItems:'center',gap:10,padding:'0 20px',background:t.color.paper}}><span style={{width:11,height:11,borderRadius:'50%',background:t.color.coral}}/><span style={{width:11,height:11,borderRadius:'50%',background:t.color.yellow}}/><span style={{width:11,height:11,borderRadius:'50%',background:t.color.mint}}/><span style={{marginLeft:15,fontSize:18,color:t.color.muted}}>{label}</span></div>
  {src ? <Img src={staticFile(src)} style={{width:'100%',height:'calc(100% - 50px)',objectFit:'contain'}}/> : children}
</Card>;
