export type Material = {
  id:string; src:string; kind:'image'|'video'; width:number; height:number;
  crop?:{x:number;y:number;width:number;height:number};
};

// Crops are composition viewports. Original user files remain unchanged.
export const materials:Record<string, Material> = {
  logo:{id:'logo',src:'materials/identity-reference.jpg',kind:'image',width:667,height:641,crop:{x:161,y:146,width:380,height:100}},
  classroom:{id:'classroom',src:'materials/classroom-reference.jpg',kind:'image',width:1162,height:876,crop:{x:474,y:246,width:600,height:377}},
  molecule:{id:'molecule',src:'materials/multi-reference.jpg',kind:'image',width:1170,height:880,crop:{x:73,y:246,width:474,height:391}},
  experiment:{id:'experiment',src:'materials/multi-reference.jpg',kind:'image',width:1170,height:880,crop:{x:591,y:248,width:487,height:153}},
  coding:{id:'coding',src:'materials/multi-reference.jpg',kind:'image',width:1170,height:880,crop:{x:593,y:483,width:485,height:155}},
};
