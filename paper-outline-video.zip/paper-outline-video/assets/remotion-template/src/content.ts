import type {Accent} from './tokens';

export type Item = {title: string; description: string; accent: Accent};
export type Caption = {from: number; to: number; text: string};
export type SceneData = {
  label: string; before: string; emphasis: string; after?: string;
  description: string; accent: Accent; tags: string[];
  items: Item[]; summary: string; captions: Caption[];
};

// Each scene lasts 180 frames / 6 seconds. Caption timing is local to the scene.
// This is original demonstration copy, not a transcription of the reference videos.
export const content: SceneData[] = [
  {
    label: '从收藏到使用', before: '让每一次记录，', emphasis: '接上下一步',
    description: '给 AI 一份有背景、有进度、能继续使用的工作笔记。', accent: 'lime',
    tags: ['AI NOTES', 'CONTEXT', 'NEXT STEP'],
    items: [
      {title: '项目背景', description: '目标是什么\n资料在哪里', accent: 'cyan'},
      {title: '当前进度', description: '已经做了什么\n还差哪一步', accent: 'purple'},
      {title: '下一步行动', description: '把一次记录\n变成下一次输入', accent: 'lime'},
    ],
    summary: '每次结束，都留下一个可以继续的起点。',
    captions: [{from: 0, to: 90, text: '记下来的信息，也可以推动下一次行动。'}, {from: 90, to: 180, text: '从一份能够持续更新的工作笔记开始。'}],
  },
  {
    label: '组织信息', before: '一份工作笔记，', emphasis: '三个重点',
    description: '让背景、进度和下一步各有位置，打开就能接着做。', accent: 'cyan',
    tags: ['BACKGROUND', 'PROGRESS', 'ACTION'],
    items: [
      {title: '背景', description: '目标与约束\n资料与参考来源', accent: 'coral'},
      {title: '进度', description: '已完成的工作\n关键决定与理由', accent: 'cyan'},
      {title: '下一步', description: '还没解决的问题\n可以立即做的动作', accent: 'purple'},
    ],
    summary: '先把信息放对位置，再交给 AI 使用。',
    captions: [{from: 0, to: 85, text: '先写清背景，再记录已经完成的工作。'}, {from: 85, to: 180, text: '最后留下一条具体的下一步行动。'}],
  },
  {
    label: '持续积累', before: '任务结束后，', emphasis: '把结果写回来',
    description: '用同一份笔记连接输入、执行、记录与后续复用。', accent: 'purple',
    tags: ['INPUT', 'EXECUTE', 'WRITE BACK'],
    items: [
      {title: '写清', description: '目标 / 材料', accent: 'coral'},
      {title: '执行', description: 'AI 协助推进', accent: 'cyan'},
      {title: '写回', description: '结果 / 判断', accent: 'lime'},
      {title: '复用', description: '继续下一步', accent: 'purple'},
    ],
    summary: '背景 → 执行 → 结果写回 → 下次继续',
    captions: [{from: 0, to: 90, text: '一次任务结束，把结果和关键判断写回笔记。'}, {from: 90, to: 180, text: '下一次开始，就有了可以继续使用的上下文。'}],
  },
  {
    label: '示意演示', before: '把一次讨论，', emphasis: '整理成行动',
    description: '用简短的记录，留下这次做了什么、下次从哪里开始。', accent: 'pink',
    tags: ['EXAMPLE', 'LOCAL NOTE', 'NEXT ACTION'],
    items: [
      {title: '先留结论', description: '用一句话说明\n这次完成了什么', accent: 'pink'},
      {title: '再写下一步', description: '明确下一次\n要做的具体动作', accent: 'cyan'},
    ],
    summary: '示意笔记 · 非真实产品界面',
    captions: [{from: 0, to: 90, text: '比如，记录今天整理了哪些参考素材。'}, {from: 90, to: 180, text: '再写上：下一步，完成第一版分镜。'}],
  },
  {
    label: '从今天开始', before: '先做一份，', emphasis: '真正用起来',
    description: '选一个正在推进的项目，保持记录简短、明确、可继续。', accent: 'coral',
    tags: ['START SMALL', 'KEEP UPDATING', 'REUSE'],
    items: [
      {title: '选一个真实项目', description: '从你今天就在做的事情开始', accent: 'lime'},
      {title: '完成后更新笔记', description: '留下结果、决定和未解决的问题', accent: 'cyan'},
      {title: '下次打开接着做', description: '让已有记录成为新的起点', accent: 'purple'},
    ],
    summary: '让记录积累，让工作继续。',
    captions: [{from: 0, to: 90, text: '从一个真实项目开始，完成后就更新记录。'}, {from: 90, to: 180, text: '让每一次工作，都为下一次留下起点。'}],
  },
];
