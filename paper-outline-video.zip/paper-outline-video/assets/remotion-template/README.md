# Paper Outline · Remotion template

4:3、1440×1080、30fps的中文图解模板。默认合成`PaperNotes`为五页、30秒、无声风格样片。

```sh
pnpm install
pnpm run dev
pnpm run lint
pnpm run render
```

视频输出在`out/style-demo.mp4`。预览服务打印本地地址后在浏览器打开。已有依赖时，也可用`node node_modules/@remotion/cli/remotion-cli.js studio --no-open`直接运行。

素材增强版合成为`RealMaterialDemo`，18秒，使用用户提供的三张真实截图。运行`pnpm run render:materials`输出`out/real-material-demo.mp4`。素材来源与裁切在`public/materials/manifest.json`；代码配置在`src/materials.ts`。窗口支持`kind: 'image'`或`kind: 'video'`，视频默认静音，按实际素材尺寸配置；本轮只有静态截图分支通过渲染验证。

修改`src/content.ts`替换文案与字幕，修改`src/tokens.ts`调整风格，修改`src/scenes/`改变布局。镜头时间在`Video.tsx`中，每页默认180帧，合成总长在`Root.tsx`中。改变时长还要更新`components.tsx`的淡出范围与字幕区间。示意笔记内容在`scenes/Evidence.tsx`内。

已打包Noto Sans SC可变字体，许可见`public/fonts/OFL.txt`。字体来源：Google Fonts仓库`ofl/notosanssc`。这是参考字体的替代方案，不声称识别到原片字体。

首渲染需要Chrome/Chromium。自动下载失败时可用Remotion的`--browser-executable`指定兼容浏览器；当前机器的验证环境位于交付目录`work/chromium/`，不随干净模板复制。

渲染命令文档：https://www.remotion.dev/docs/cli/render

静帧命令文档：https://www.remotion.dev/docs/cli/still

Remotion许可遵循其官方条款：https://www.remotion.dev/license
