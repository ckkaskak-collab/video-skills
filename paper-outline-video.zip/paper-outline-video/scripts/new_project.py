"""Copy this skill's clean Remotion template into a new, absent directory."""
import argparse
import shutil
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('destination', type=Path)
args = parser.parse_args()
destination = args.destination.expanduser().resolve()
source = Path(__file__).resolve().parents[1] / 'assets' / 'remotion-template'
if destination.exists():
    parser.error(f'Destination already exists: {destination}; choose a new directory.')
if source == destination or source in destination.parents:
    parser.error('Destination must be outside the source template.')
shutil.copytree(source, destination, ignore=shutil.ignore_patterns('node_modules', '.git', '.cache', 'out', 'build', 'dist', '.DS_Store'))
print(f'Created: {destination}\nNext: cd into this directory, run pnpm install, then pnpm run dev.')
