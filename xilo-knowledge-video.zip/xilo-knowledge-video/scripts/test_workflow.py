#!/usr/bin/env python3
"""Offline regression checks using temporary copies and synthetic silent audio."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import wave

ROOT = Path(__file__).resolve().parents[1]
RESULTS = []


def run(name, tool, args, success=True):
    result = subprocess.run([sys.executable, str(ROOT / 'scripts' / tool), *map(str, args)],
                            capture_output=True, text=True)
    good = (result.returncode == 0) == success and 'Traceback' not in result.stderr
    RESULTS.append({'case': name, 'passed': good})
    if not good:
        raise AssertionError(name + '\n' + result.stdout + result.stderr)
    return result


def main():
    with TemporaryDirectory(prefix='xilo-workflow-test-') as work:
        temp = Path(work)
        def save(name, obj):
            path = temp / name
            path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')
            return path
        images = []
        for role, name in [('character', 'green-ip-three-views-v1.png'), ('scene', 'green-ip-studio-v1.png'), ('brush_style', 'green-ip-brush-v1.png')]:
            p = temp / name
            p.write_bytes((ROOT / 'assets' / name).read_bytes())
            images.append({'role': role, 'path': str(p)})
        wav = temp / 'synthetic-silence.wav'
        with wave.open(str(wav), 'wb') as audio:
            audio.setparams((1, 2, 44100, 0, 'NONE', 'not compressed'))
            audio.writeframes(b'\0\0' * 88200)
        script = temp / 'script.txt'
        script.write_text('今天学知识，一起看变化。', encoding='utf-8')
        alignment = temp / 'alignment.txt'
        valid_align = '[0ms-1000ms] 今天学知识\n[1000ms-2000ms] 一起看变化\n'
        alignment.write_text(valid_align, encoding='utf-8')
        row = '| S001 | 0–2000ms | 今天学知识，一起看变化。 | 人物 | 中景讲解 | 指向书页 | 承接书页 |'
        specs = [
            {'stage': 1, 'inputs': {'script': {'path': str(script)}, 'voice_id': 'offline-test-id', 'speed': 1.0, 'tts_access': 'offline fixture, no service called'}},
            {'stage': 2, 'inputs': {'script': {'path': str(script)}, 'alignment': {'path': str(alignment)}}},
            {'stage': 3, 'inputs': {}, 'images': images[:1]},
            {'stage': 4, 'inputs': {'shot_row': row}, 'images': images},
            {'stage': 5, 'inputs': {'shot_row': row, 'perspective': '主角视角'}, 'images': images},
            {'stage': 6, 'inputs': {'shot_id': 'S001', 'duration_ms': 2000, 'voice_text': '一起看变化', 'understanding': '展示变化', 'broll_type': '无素材', 'semantic_structure': '展开', 'template_library': {'path': None, 'status': 'not_configured'}, 'ui_spec': '离线测试规范'}},
        ]
        packets = []
        for spec in specs:
            stage = spec['stage']
            source = save(f'input-{stage}.json', spec)
            packet = temp / f'call-{stage}.json'
            run(f'build stage {stage}', 'prepare_call.py', ['--input', source, '--output', packet])
            run(f'check stage {stage}', 'prepare_call.py', ['--check', packet])
            packets.append(packet)
        detail_spec = deepcopy(specs[2])
        detail_spec['images'].append({'role': 'detail', 'path': str(ROOT / 'assets/green-ip-brush-v2.png')})
        run('three views accept optional detail reference', 'prepare_call.py', ['--input', save('detail.json', detail_spec), '--output', temp / 'detail-call.json'])
        base_frame = temp / 'base-frame.png'
        base_frame.write_bytes(Path(images[0]['path']).read_bytes())
        continuity_spec = deepcopy(specs[3])
        continuity_spec['images'].append({'role': 'base_frame', 'path': str(base_frame)})
        continuity_spec['inputs']['continuity'] = {'active_hand': 'left', 'screen_side': 'right', 'prop_state': 'none', 'scene_lock': 'keep', 'mouth': 'closed'}
        continuity_packet = temp / 'continuity-call.json'
        run('A-roll accepts a locked base frame', 'prepare_call.py', ['--input', save('continuity.json', continuity_spec), '--output', continuity_packet])
        run('locked call packet verifies', 'prepare_call.py', ['--check', continuity_packet])
        missing_lock = deepcopy(continuity_spec); del missing_lock['inputs']['continuity']
        run('base frame requires continuity constraints', 'prepare_call.py', ['--input', save('missing-lock.json', missing_lock), '--output', temp / 'missing-lock-call.json'], False)
        wrong_order = deepcopy(continuity_spec); wrong_order['images'].reverse()
        run('base frame cannot replace standard reference order', 'prepare_call.py', ['--input', save('wrong-base-order.json', wrong_order), '--output', temp / 'wrong-base-call.json'], False)
        base_frame.write_bytes(b'changed base frame')
        run('changed base frame invalidates packet', 'prepare_call.py', ['--check', continuity_packet], False)
        run('refuse overwrite', 'prepare_call.py', ['--input', temp / 'input-3.json', '--output', packets[2]], False)
        bad = deepcopy(specs[3]); bad['inputs'] = {}
        run('missing shot input', 'prepare_call.py', ['--input', save('missing.json', bad), '--output', temp / 'missing-call.json'], False)
        bad = deepcopy(specs[3]); bad['images'].reverse()
        run('wrong image roles order', 'prepare_call.py', ['--input', save('order.json', bad), '--output', temp / 'order-call.json'], False)
        bad = json.loads(packets[3].read_text()); bad['tool_arguments']['prompt'] = 'changed\n' + bad['tool_arguments']['prompt']
        run('changed original in packet', 'prepare_call.py', ['--check', save('tampered.json', bad)], False)
        bad = json.loads(packets[3].read_text()); bad['tool_arguments']['referenced_image_paths'].reverse()
        run('changed actual image arguments', 'prepare_call.py', ['--check', save('tampered-order.json', bad)], False)
        script.write_text('定稿已改动', encoding='utf-8')
        run('source script changed after preparation', 'prepare_call.py', ['--check', packets[0]], False)
        script.write_text('今天学知识，一起看变化。', encoding='utf-8')
        p = Path(images[0]['path']); original_image = p.read_bytes(); p.write_bytes(b'changed')
        run('image changed after preparation', 'prepare_call.py', ['--check', packets[2]], False)
        p.write_bytes(original_image)
        existing = {'stage': 1, 'mode': 'existing_audio', 'inputs': {'script': {'path': str(script)}, 'audio_path': str(wav)}, 'deviations': ['用户已有配音，仅核对与对齐；本例为离线测试']}
        run('existing audio without voice credentials', 'prepare_call.py', ['--input', save('existing.json', existing), '--output', temp / 'existing-call.json'])
        existing['deviations'] = []
        run('existing audio must declare deviation', 'prepare_call.py', ['--input', save('undeclared.json', existing), '--output', temp / 'undeclared-call.json'], False)
        args = ['--wav', wav, '--script', script, '--alignment', alignment]
        run('valid complete phrase timeline', 'validate_timeline.py', args)
        for name, changed in [('gap', valid_align.replace('1000ms-2000', '1100ms-2000')), ('overlap', valid_align.replace('1000ms-2000', '900ms-2000')), ('wrong end', valid_align.replace('2000ms', '1900ms')), ('wrong text', valid_align.replace('知识', '故事'))]:
            alignment.write_text(changed, encoding='utf-8')
            run('reject timeline ' + name, 'validate_timeline.py', args, False)
        alignment.write_text(valid_align, encoding='utf-8')
        shots = [{'id': 'S001', 'start_ms': 0, 'end_ms': 1000, 'narration': '今天学知识', 'type': '人物', 'design': '中景', 'changes': '指向书页', 'handoff': '沿指向进入下一镜'}, {'id': 'S002', 'start_ms': 1000, 'end_ms': 2000, 'narration': '一起看变化', 'type': '信息图形', 'design': '书页展开', 'changes': '展开关系', 'handoff': '结论停留'}]
        shot_file = save('shots.json', shots)
        run('valid seven-column shot mapping', 'validate_timeline.py', args + ['--shots', shot_file])
        bad = deepcopy(shots); bad[0]['end_ms'] = 900; bad[1]['start_ms'] = 900
        run('reject non-phrase shot boundary', 'validate_timeline.py', args + ['--shots', save('wrong-shots.json', bad)], False)
        bad = deepcopy(shots); bad[1]['narration'] = '不相关文案'
        run('reject shot narration mismatch', 'validate_timeline.py', args + ['--shots', save('wrong-narration.json', bad)], False)
        script.write_text('结果为1.5倍，一起看变化。', encoding='utf-8')
        alignment.write_text('[0ms-1000ms] 结果为15倍\n[1000ms-2000ms] 一起看变化\n', encoding='utf-8')
        run('decimal number mismatch is not normalized away', 'validate_timeline.py', args, False)
    print(json.dumps({'passed': True, 'case_count': len(RESULTS), 'cases': RESULTS,
                      'scope': 'Offline packet/timeline checks only. Synthetic silence is not TTS or acoustic-alignment validation.'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
