#!/usr/bin/env python3
"""Build/check a call packet without changing any original prompt. No service calls."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
FIELDS = {
    1: ['script', 'voice_id', 'speed', 'tts_access'],
    2: ['script', 'alignment'],
    3: [],
    4: ['shot_row'],
    5: ['shot_row', 'perspective'],
    6: ['shot_id', 'duration_ms', 'voice_text', 'understanding', 'broll_type',
        'semantic_structure', 'template_library', 'ui_spec'],
}
LABELS = {
    'script': '原文案或定稿路径', 'voice_id': '音色ID', 'speed': '语速',
    'tts_access': '已核实的调用方式（不得包含凭据）', 'alignment': '配音时间轴',
    'shot_row': '视觉编排表完整一行', 'perspective': '我想要的视角',
    'shot_id': '镜头号', 'duration_ms': '时长（毫秒）', 'voice_text': '配音内容',
    'understanding': '观众要理解的一句话', 'broll_type': 'B-roll类型',
    'semantic_structure': '语义结构', 'template_library': '本地模板库路径及实际状态',
    'ui_spec': '本次UI规范', 'audio_path': '用户已有音频路径',
    'notes': '本次补充要求（须人工检查是否改变原文意思）',
    'continuity': '连续性约束（项目补充）',
}
ROLES = {3: ['character'], 4: ['character', 'scene', 'brush_style'],
         5: ['character', 'scene', 'brush_style']}
PERSPECTIVES = ['主持人视角', '主角视角', '配角视角', '第一人称视角']


def present(value):
    return value is not None and str(value).strip() not in ('', '[]', '{}')


def build(spec):
    if not isinstance(spec, dict):
        raise ValueError('Input spec must be a JSON object')
    verified = subprocess.run([sys.executable, str(ROOT / 'scripts/verify_original_prompts.py')],
                              capture_output=True, text=True)
    if verified.returncode:
        raise ValueError('Original prompt verification failed: ' + (verified.stderr or verified.stdout).strip())
    stage = spec['stage']
    if type(stage) is not int or stage not in FIELDS:
        raise ValueError('stage must be an integer from 1 to 6')
    mode = spec.get('mode', 'original')
    if mode not in ('original', 'existing_audio') or (mode == 'existing_audio' and stage != 1):
        raise ValueError('existing_audio is only available at stage 1')
    fields = spec.get('inputs', {})
    if not isinstance(fields, dict):
        raise ValueError('inputs must be a JSON object')
    required = FIELDS[stage] if mode == 'original' else ['script', 'audio_path']
    allowed = set(required) | {'notes'}
    if stage in (4, 5):
        allowed.add('continuity')
    if set(fields) - allowed:
        raise ValueError('Unknown input fields: ' + ', '.join(sorted(set(fields) - allowed)))
    missing = [key for key in required if not present(fields.get(key))]
    if missing:
        raise ValueError('Missing inputs: ' + ', '.join(missing))
    for key, value in fields.items():
        if key == 'continuity':
            keys = {'active_hand', 'screen_side', 'prop_state', 'scene_lock', 'mouth'}
            if not isinstance(value, dict) or set(value) != keys or any(not isinstance(v, str) or not v.strip() for v in value.values()):
                raise ValueError('continuity requires active_hand, screen_side, prop_state, scene_lock and mouth as nonempty text')
            continue
        if key in ('speed', 'duration_ms'):
            continue
        if key in ('script', 'alignment', 'shot_row', 'template_library', 'ui_spec') and isinstance(value, dict):
            continue
        if not isinstance(value, str) or not value.strip():
            raise ValueError(key + ' must be nonempty text or a supported object')
    if stage == 5 and fields['perspective'] not in PERSPECTIVES:
        raise ValueError('Choose exactly one supported perspective')
    if 'speed' in fields and (type(fields['speed']) not in (int, float) or not math.isfinite(fields['speed']) or fields['speed'] <= 0):
        raise ValueError('speed must be a positive number')
    if stage == 6:
        if type(fields['duration_ms']) is not int or fields['duration_ms'] <= 0:
            raise ValueError('duration_ms must be a positive integer')
        if fields['broll_type'] not in ['有素材', '无素材', '纯文字']:
            raise ValueError('Unsupported B-roll type')
        if fields['semantic_structure'] not in ['对比', '聚合', '筛选', '层级', '因果', '替换', '展开']:
            raise ValueError('Unsupported semantic structure')
    input_files = []
    for key in ('script', 'alignment', 'shot_row'):
        value = fields.get(key)
        if isinstance(value, dict):
            if set(value) != {'path'} or not Path(value['path']).is_absolute() or not Path(value['path']).is_file():
                raise ValueError(key + ': path input must name an existing absolute file')
            input_files.append({'field': key, 'path': value['path'],
                                'sha256': hashlib.sha256(Path(value['path']).read_bytes()).hexdigest()})
    if mode == 'existing_audio':
        p = Path(fields['audio_path'])
        if not p.is_absolute() or not p.is_file():
            raise ValueError('Existing audio file is missing or not absolute')
        input_files.append({'field': 'audio_path', 'path': str(p),
                            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    images = spec.get('images', [])
    if not isinstance(images, list) or any(not isinstance(item, dict) for item in images):
        raise ValueError('images must be a list of role/path objects')
    roles = [item['role'] for item in images]
    expected = ROLES.get(stage, [])
    base_frame = stage in (4, 5) and roles == expected + ['base_frame']
    detail = stage == 3 and roles == expected + ['detail']
    if roles != expected and not base_frame and not detail:
        raise ValueError('Image order must be: ' + str(ROLES.get(stage, [])))
    if base_frame and 'continuity' not in fields:
        raise ValueError('A base_frame requires explicit continuity constraints')
    image_records = []
    for item in images:
        p = Path(item['path'])
        if not p.is_absolute() or not p.is_file():
            raise ValueError('Image file is missing or not absolute: ' + str(p))
        image_records.append({'role': item['role'], 'path': str(p),
                              'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    deviations = spec.get('deviations', [])
    if not isinstance(deviations, list) or any(not isinstance(d, str) or not d.strip() for d in deviations):
        raise ValueError('deviations must be a list of nonempty explanations')
    if mode == 'existing_audio' and not deviations:
        raise ValueError('existing_audio requires an explicit deviation explaining why synthesis is skipped')
    manifest = json.loads((ROOT / 'references/source-manifest.json').read_text())
    entry = next(item for item in manifest['prompts'] if item['index'] == stage)
    original = (ROOT / entry['path']).read_bytes().decode('utf-8')
    lines = ['【本次输入｜项目补充，非作者原文】', '执行模式：' + mode]
    if mode == 'existing_audio':
        lines.append('按用户提供已有配音的要求，跳过原文第一步合成，仅执行核对和对齐；不重新合成音频。')
    for key in required + [k for k in ('notes', 'continuity') if k in fields]:
        value = fields[key]
        rendered = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        lines.append(LABELS[key] + '：' + rendered)
    for i, item in enumerate(image_records, 1):
        lines.append('参考图' + str(i) + '（' + item['role'] + '）：' + item['path'])
    if deviations:
        lines += ['【相对原文的执行差异｜须有当前用户指令或既有授权依据】'] + deviations
    prompt = original + '\n\n' + '\n'.join(lines) + '\n'
    args = {'prompt': prompt}
    if images:
        args['referenced_image_paths'] = [item['path'] for item in image_records]
    return {'schema_version': 1, 'spec': spec, 'source_sha256': entry['sha256'],
            'images': image_records, 'input_files': input_files, 'tool_arguments': args,
            'prompt_sha256': hashlib.sha256(prompt.encode('utf-8')).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--input', type=Path, help='JSON spec to build')
    group.add_argument('--check', type=Path, help='Verify a saved call packet immediately before dispatch')
    group.add_argument('--describe', action='store_true', help='Print required input fields and image roles')
    parser.add_argument('--output', type=Path, help='New output packet; refuses overwrite')
    args = parser.parse_args()
    try:
        if args.describe:
            print(json.dumps({'required_inputs': FIELDS, 'image_roles': ROLES,
                              'optional_image_role': {'3': 'detail after character', '4': 'base_frame after the three required images', '5': 'base_frame after the three required images'},
                              'existing_audio_inputs': ['script', 'audio_path']}, ensure_ascii=False, indent=2))
        elif args.check:
            saved = json.loads(args.check.read_text(encoding='utf-8'))
            if saved != build(saved['spec']):
                raise ValueError('Call packet differs from original text, inputs, image content or order')
            print('PASS: call packet, original text, inputs and referenced images match')
        else:
            if not args.output:
                raise ValueError('--output is required with --input')
            packet = build(json.loads(args.input.read_text(encoding='utf-8')))
            with args.output.open('x', encoding='utf-8') as f:
                json.dump(packet, f, ensure_ascii=False, indent=2)
            print('Created: ' + str(args.output))
    except (ValueError, KeyError, TypeError, OSError, subprocess.CalledProcessError) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
