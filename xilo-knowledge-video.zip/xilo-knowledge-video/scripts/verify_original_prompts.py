#!/usr/bin/env python3
"""Verify the six unchanged X article prompts; optionally compare source capture."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def fnv1a_utf16(text):
    data = text.encode("utf-16-le")
    value = 2166136261
    for offset in range(0, len(data), 2):
        code_unit = int.from_bytes(data[offset:offset + 2], "little")
        value = ((value ^ code_unit) * 16777619) & 0xffffffff
    return f"{value:08x}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--capture", type=Path, help="Original browser-text capture JSON")
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / "references/source-manifest.json").read_text(encoding="utf-8"))
    items = manifest["prompts"]
    errors = []
    if len(items) != 6 or [item["index"] for item in items] != list(range(1, 7)):
        errors.append("The manifest must contain all six original blocks in article order.")
    capture = None
    if args.capture:
        source = json.loads(args.capture.read_text(encoding="utf-8"))
        capture = {item["index"]: item["text"] for item in source["prompts"]}
        if source["source_url"] != manifest["source_url"] or set(capture) != set(range(1, 7)):
            errors.append("Source capture URL or prompt set differs.")
    for item in items:
        path = root / item["path"]
        if not path.is_file():
            errors.append(f"Missing: {item['path']}")
            continue
        raw = path.read_bytes()
        text = raw.decode("utf-8")
        checks = {
            "bytes_utf8": len(raw),
            "length_utf16": len(text.encode("utf-16-le")) // 2,
            "fnv1a_utf16": fnv1a_utf16(text),
            "sha256": hashlib.sha256(raw).hexdigest(),
        }
        for key, actual in checks.items():
            if actual != item[key]:
                errors.append(f"Changed {key}: {item['path']}")
        if capture is not None and text != capture.get(item["index"]):
            errors.append(f"Different from browser capture: {item['path']}")
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print("PASS: all six prompts match original text, whitespace and SHA-256 fingerprints.")
    if capture is not None:
        print("PASS: all six files exactly equal the browser source capture.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
