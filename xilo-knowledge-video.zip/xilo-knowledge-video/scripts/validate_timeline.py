#!/usr/bin/env python3
"""Check PCM WAV duration, continuous phrase alignment and optional seven-field shots."""
import argparse
import json
from pathlib import Path
import re
import sys
import unicodedata
import wave


def text_units(text):
    if not isinstance(text, str):
        raise ValueError('Narration must be text')
    kept = []
    for i, c in enumerate(text):
        left = text[i - 1] if i else ''
        right = text[i + 1] if i + 1 < len(text) else ''
        numeric_mark = (c in '.．,:：/' and left.isdecimal() and right.isdecimal()) or (c in '-−' and right.isdecimal()) or c in '%％‰'
        if numeric_mark or (not c.isspace() and not unicodedata.category(c).startswith('P')):
            kept.append(c)
    return ''.join(kept)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wav', required=True, type=Path)
    parser.add_argument('--script', required=True, type=Path)
    parser.add_argument('--alignment', required=True, type=Path)
    parser.add_argument('--shots', type=Path, help='JSON list; fields documented in production.md')
    args = parser.parse_args()
    errors, warnings = [], []
    try:
        with wave.open(str(args.wav), 'rb') as audio:
            duration = round(audio.getnframes() * 1000 / audio.getframerate())
            if audio.getframerate() != 44100 or audio.getnchannels() != 1:
                errors.append('Delivery WAV must be 44100 Hz mono; preserve source separately')
        spans = []
        for n, line in enumerate(args.alignment.read_text(encoding='utf-8').splitlines(), 1):
            if not line.strip():
                continue
            match = re.fullmatch(r'\[(\d+)ms-(\d+)ms\]\s+(.+)', line)
            if not match:
                raise ValueError('Invalid alignment format at line ' + str(n))
            start, end, text = int(match[1]), int(match[2]), match[3]
            if end <= start or not text_units(text):
                errors.append('Invalid phrase at line ' + str(n))
            if start != (spans[-1][1] if spans else 0):
                errors.append('Gap/overlap or nonzero start at line ' + str(n))
            if not 5 <= len(text_units(text)) <= 15:
                warnings.append('Review phrase length at line ' + str(n))
            spans.append((start, end, text))
        if not spans or spans[-1][1] != duration:
            errors.append('Last phrase must end at WAV duration rounded to milliseconds')
        narration = text_units(args.script.read_text(encoding='utf-8'))
        if narration != text_units(''.join(s[2] for s in spans)):
            errors.append('Alignment text differs from approved script (ignoring punctuation/whitespace only)')
        if args.shots:
            shots = json.loads(args.shots.read_text(encoding='utf-8'))
            if not isinstance(shots, list) or any(not isinstance(shot, dict) for shot in shots):
                raise ValueError('Shots must be a JSON list of objects')
            required = {'id', 'start_ms', 'end_ms', 'narration', 'type', 'design', 'changes', 'handoff'}
            boundaries = {t for s in spans for t in s[:2]}
            previous_end = 0
            for i, shot in enumerate(shots, 1):
                if set(shot) != required:
                    raise ValueError('Invalid shot fields at row ' + str(i))
                start, end = shot['start_ms'], shot['end_ms']
                if type(start) is not int or type(end) is not int or end <= start:
                    raise ValueError('Invalid shot time at row ' + str(i))
                if shot['id'] != f'S{i:03d}' or start != previous_end or start not in boundaries or end not in boundaries:
                    errors.append('Shot numbering, coverage or phrase boundary mismatch at row ' + str(i))
                expected = ''.join(s[2] for s in spans if s[0] >= start and s[1] <= end)
                if text_units(shot['narration']) != text_units(expected):
                    errors.append('Shot narration mismatch at row ' + str(i))
                if shot['type'] not in ['人物', '场景', '真实素材', '信息图形', '文字动效']:
                    errors.append('Invalid shot type at row ' + str(i))
                if any(not isinstance(shot[k], str) or not shot[k].strip() for k in ['design', 'changes', 'handoff']):
                    errors.append('Missing shot design, changes or handoff at row ' + str(i))
                previous_end = end
            if not shots or previous_end != duration:
                errors.append('Shots do not cover the complete audio')
        report = {'passed': not errors, 'audio_duration_ms': duration, 'phrase_count': len(spans),
                  'last_end_ms': spans[-1][1] if spans else None, 'errors': errors, 'warnings': warnings,
                  'limit': 'Structural checks only; listen to verify pronunciation, silence and actual synchronization.'}
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return int(bool(errors))
    except (ValueError, KeyError, TypeError, OSError, EOFError, wave.Error) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
